//
//  BIDAdFormat.h
//  bidapp
//
//  Created by Vasiliy Masnev on 22.02.2023.
//  Copyright 2023 bidapp. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BIDAdFormat;

@protocol BIDAdFormat<NSObject>

@property (class,nonatomic,readonly) id<BIDAdFormat> interstitial;
@property (class,nonatomic,readonly) id<BIDAdFormat> rewarded;
@property (class,nonatomic,readonly) id<BIDAdFormat> banner_320x50;
@property (class,nonatomic,readonly) id<BIDAdFormat> banner_300x250;
@property (class,nonatomic,readonly) id<BIDAdFormat> banner_728x90;

-(BOOL)isInterstitial;
-(BOOL)isRewarded;
-(BOOL)isBanner_320x50;
-(BOOL)isBanner_300x250;
-(BOOL)isBanner_728x90;

@property (nonatomic,readonly) NSString* name;
@property (nonatomic,readonly) NSString* slug;
@property (nonatomic,readonly) CGSize size;
@property (nonatomic,readonly) CGRect bounds;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

@interface BIDAdFormat : NSObject<BIDAdFormat>
@end

NS_ASSUME_NONNULL_END
