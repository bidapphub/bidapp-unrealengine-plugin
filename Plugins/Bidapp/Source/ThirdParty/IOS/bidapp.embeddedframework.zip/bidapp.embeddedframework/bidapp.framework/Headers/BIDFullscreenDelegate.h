//
//  BIDFullscreenDelegate.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 4/5/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIViewController;
@class BIDAdInfo;

NS_ASSUME_NONNULL_BEGIN

#pragma mark - BIDFullscreenLoadDelegate

@protocol BIDFullscreenLoadDelegate <NSObject>
- (void)didLoadAd:(BIDAdInfo*)adInfo;
- (void)didFailToLoadAd:(BIDAdInfo*)adInfo error:(NSError *)error;
@end

#pragma mark - BIDFullscreenDelegate

@protocol BIDFullscreenDelegate <NSObject>
- (nonnull UIViewController*)viewControllerForDisplayAd;
@optional
- (void)didDisplayAd:(BIDAdInfo*)adInfo;
- (void)didClickAd:(BIDAdInfo*)adInfo;
- (void)didHideAd:(BIDAdInfo*)adInfo;
- (void)didFailToDisplayAd:(BIDAdInfo*)adInfo error:(NSError *)error;
- (void)allNetworksDidFailToDisplayAd;
@end

#pragma mark - BIDInterstitialDelegate

@protocol BIDInterstitialDelegate <BIDFullscreenDelegate>
@end

#pragma mark - BIDRewardedDelegate

@protocol BIDRewardedDelegate <BIDFullscreenDelegate>
@optional
- (void)didRewardUser;
@end

NS_ASSUME_NONNULL_END
