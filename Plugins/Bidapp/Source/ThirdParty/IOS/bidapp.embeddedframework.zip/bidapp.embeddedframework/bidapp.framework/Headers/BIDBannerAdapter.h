//
//  BIDBannerAdapterDelegate.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 27/5/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BIDAdFormat;

NS_ASSUME_NONNULL_BEGIN

@protocol BIDNetworkBanner<NSObject>

-(void)onLoad;
-(void)onFailedToLoad:(NSError*)error;

-(void)onDisplay;
-(void)onFailedToDisplay:(NSError*)error;
-(void)onClick;

@end

@protocol BIDBannerAdapter<NSObject>

+ (instancetype)bannerWithNetworkBanner:(id<BIDNetworkBanner>)adapter
                                    SDK:(id)sdk
                                  adTag:(NSString*)adTag
                                 format:(id<BIDAdFormat>)format
                                ownerId:(NSString * __nullable)ownerId;

-(UIView*)nativeAdView;

- (BOOL)isAdReady;
- (void)load;

//Should zero all ad references in this method to avoid retain cycles
-(void)prepareForDealloc;

-(BOOL)showOnView:(UIView*)view error:(NSError *__autoreleasing  _Nullable *)error;

@optional
-(BOOL)waitForAdToShow;
-(NSNumber* __nullable)revenue;

+(NSPointerArray*)delegateMethodsToValidate;

@end

NS_ASSUME_NONNULL_END
