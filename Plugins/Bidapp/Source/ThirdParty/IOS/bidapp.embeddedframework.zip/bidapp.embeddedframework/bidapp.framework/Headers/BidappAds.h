//
//  BidappAds.h
//  bidapp
//
//  Created by Vasiliy Masnev on 30.01.2023.
//  Copyright 2023 bidapp. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT const NSInteger BIDNetworkId_Applovin;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_ApplovinMax;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Unity;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Liftoff;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Chartboost;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Admob;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_StartApp;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Facebook;
FOUNDATION_EXPORT const NSInteger BIDNetworkId_Fyber;

@class BIDConfiguration;

NS_ASSUME_NONNULL_BEGIN

@interface BidappAds : NSObject

+(void)startWithPubid:(NSString *)pubid config:(BIDConfiguration*)config;

@property(nonatomic,strong,class) NSString* userId;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
