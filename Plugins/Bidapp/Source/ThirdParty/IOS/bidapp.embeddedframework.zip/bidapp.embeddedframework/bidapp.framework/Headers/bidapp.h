//
//  bidapp.h
//  bidapp
//
//  Created by Vasiliy Masnev on 30.01.2023.
//  Copyright 2023 bidapp. All rights reserved.

#import <Foundation/Foundation.h>

//! Project version number for bidapp.
FOUNDATION_EXPORT double bidappVersionNumber;

//! Project version string for bidapp.
FOUNDATION_EXPORT const unsigned char bidappVersionString[];

#import <bidapp/BidappAds.h>
#import <bidapp/BIDConfiguration.h>
#import <bidapp/BIDConfiguration+Waterfall.h>
#import <bidapp/BIDAdFormat.h>
#import <bidapp/BIDInterstitial.h>
#import <bidapp/BIDRewarded.h>
#import <bidapp/BIDBannerView.h>
#import <bidapp/BIDAdInfo.h>
#import <bidapp/BIDConsent.h>
