//
//  BIDNetworkAdapterDelegate.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 27/5/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <bidapp/BIDConsentProtocol.h>

NS_ASSUME_NONNULL_BEGIN

typedef BOOL(^validate_selectors_t)(Class c, NSPointerArray* selectors);

@protocol BIDNetworkSDK<NSObject>

-(BOOL)initializationInProgress;
-(void)onInitializationStart;
-(void)onInitializationComplete:(BOOL)initialized error:(NSError* __nullable)error;

@end

@protocol BIDNetworkAdapter<NSObject>

-(id)initWithNetworkSDK:(id<BIDNetworkSDK>)networkSDK SDKKey:(NSString*)sdkKey secondKey:(NSString* __nullable)secondKey;

- (void)initializeSDK;
- (BOOL)isInitialized;
+ (BOOL)sdkAvailableWithCompatibleVersion:(validate_selectors_t)validate;
- (void)enableTesting;
- (void)enableLogging;
- (void)setConsent:(id<BIDConsent>)consent;

@optional
- (id __nullable)sharedNativeSDK;
- (void)setUserId:(NSString*)userId;

+(NSPointerArray*)delegateMethodsToValidate;

@end

NS_ASSUME_NONNULL_END
