//
//  BIDConsent.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 19/6/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BIDConsent : NSObject

/**
 GDPR == @YES if consent is given, otherwise @NO
 */
@property(nonatomic,strong,class) NSNumber* GDPR;

/**
 CCPA == @YES if consent is given (e.g. opt in sale), otherwise @NO (e.g. opt out sale)
 */
@property(nonatomic,strong,class) NSNumber* CCPA;

/**
 COPPA == @YES if user is subject to COPPA regulations (e.g. user is a kid, an age restricted user), otherwise @NO (e.g user is an adult)
 */
@property(nonatomic,strong,class) NSNumber* COPPA;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
