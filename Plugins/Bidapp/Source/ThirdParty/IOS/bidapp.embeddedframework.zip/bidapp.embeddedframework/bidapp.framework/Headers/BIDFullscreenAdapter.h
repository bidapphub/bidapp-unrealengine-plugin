//
//  BIDFullscreenAdapterDelegate.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 27/5/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BIDNetworkFullscreen<NSObject>

-(void)onAdLoaded;
-(void)onAdFailedToLoadWithError:(NSError*)error;

-(void)onDisplay;
-(void)onFailedToDisplay:(NSError*)error;
-(void)onFailedToDisplay:(NSError*)error andToClose:(BOOL)failedToClose;
-(void)onClick;
-(void)onHide;
-(void)onReward;

@end

@protocol BIDFullscreenAdapter<NSObject>

-(id)initWithNetworkFullscreen:(id<BIDNetworkFullscreen>)networkFullscreen SDK:(id)nativeSDK adTag:(NSString *)adTag_ isRewarded:(BOOL)isRewarded_;

-(BOOL)readyToShow;
-(void)load;

-(BOOL)showWithViewController:(UIViewController *)vc error:(NSError *__autoreleasing  _Nullable *)error;

@optional
-(BOOL)viewControllerNeededForDisplay;  //default = NO
-(BOOL)shouldWaitForAdToDisplay;        //default = NO
-(NSNumber* __nullable)revenue;
-(void)setUserId:(NSString*)userId;

+(NSPointerArray*)delegateMethodsToValidate;

@end

NS_ASSUME_NONNULL_END
