//
//  BIDFullscreen.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 18/4/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <bidapp/BIDFullscreenDelegate.h>

NS_ASSUME_NONNULL_BEGIN

@interface BIDFullscreen : NSObject

@property (nonatomic,weak) id<BIDFullscreenLoadDelegate> loadDelegate;
@property (nonatomic) BOOL autoload;

-(void)load;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
