//
//  BIDInterstitial.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 17/4/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <bidapp/BIDFullscreen.h>
#import <bidapp/BIDFullscreenDelegate.h>

NS_ASSUME_NONNULL_BEGIN

@interface BIDInterstitial : BIDFullscreen

-(BOOL)isAdReady;
-(void)showWithDelegate:(id<BIDInterstitialDelegate>)delegate;

- (instancetype)init;
+ (instancetype)new;

@end

NS_ASSUME_NONNULL_END
