//
//  BIDConfiguration+Waterfall.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 25/4/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <bidapp/BidappAds.h>
#import <bidapp/BIDConfiguration.h>

@class BIDAdFormat;

@interface BIDConfiguration(Waterfall)

/**
 Sets the first provider SDK initialization key for the provider with id == networksId. This key will be used by the Bidapp SDK before arrival of any waterfall data from the Bidapp server(or a custom server if you provide custom URL for waterfall data requests). The method fails in case the sdkKey is nil. Returns YES in case of success and NO in case of failure.
 */
-(BOOL)setSDKKey:(NSString*)sdkKey networkId:(NSInteger)networkId error:(NSError**)error;

/**
 Sets the first and the second provider SDK initialization keys for the provider with id == networksId. The real name for the first SDK key may vary - SDKKey, accoutId, initKey, startID etc. This keys will be used by the Bidapp SDK before arrival of any waterfall data from the Bidapp server(or a custom server if you provide custom URL for waterfall data requests). The method fails in case the sdkKey is nil. Returns YES in case of success and NO in case of failure.
 */
-(BOOL)setSDKKey:(NSString*)sdkKey secondKey:(NSString*)secondKey networkId:(NSInteger)networkId error:(NSError**)error;

/**
 Sets ad tags for the provider with id == networksId. The real names for the adTags may vary - placement, placementId, zoneId, adTagId etc. This ad tags will be used by the Bidapp SDK before arrival of any waterfall data from the Bidapp server(or a custom server if you provide custom URL for waterfall data requests). The method fails in case the adTag is nil. Returns YES in case of success and NO in case of failure.
 */
-(BOOL)setAdTag:(NSString*)adTag networkId:(NSInteger)networkId adFormat:(BIDAdFormat *)adFormat ecpm:(double)ecpm error:(NSError**)error;

@end
