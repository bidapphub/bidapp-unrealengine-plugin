//
//  BIDConsentProtocol.h
//  bidapp
//
//  Created by Mikhail Krasnorutskiy on 20/6/23.
//  Copyright © 2023 bidapp. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BIDConsent <NSObject>

-(NSNumber*)GDPR;
-(NSNumber*)CCPA;
-(NSNumber*)COPPA;

@end
