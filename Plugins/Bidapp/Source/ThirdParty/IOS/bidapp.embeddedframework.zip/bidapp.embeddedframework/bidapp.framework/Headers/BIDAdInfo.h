//
//  BIDAdInfo.h
//  bidapp
//
//  Created by Vasiliy Masnev on 05.03.2023.
//  Copyright © 2023 Vasiliy Macnev. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BIDAdFormat;
NS_ASSUME_NONNULL_BEGIN

@interface BIDAdInfo : NSObject

@property (nonatomic,readonly) BIDAdFormat *format;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

@interface BIDAdInfo(TrackingParams)

@property (nonatomic,readonly) int networkId;
@property (nonatomic,readonly) NSString* __nullable waterfallId;
@property (nonatomic,readonly) NSString* __nullable loadSessionId;
@property (nonatomic,readonly) NSString* __nullable showSessionId;
@property (nonatomic,readonly) NSNumber* __nullable revenue;
@property (nonatomic,readonly) NSString* __nullable revenuePrecision;

@end

NS_ASSUME_NONNULL_END
