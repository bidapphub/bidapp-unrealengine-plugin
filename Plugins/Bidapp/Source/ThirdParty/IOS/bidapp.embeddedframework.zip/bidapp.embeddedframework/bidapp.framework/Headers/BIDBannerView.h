//
//  BIDBannerView.h
//  bidapp
//
//  Created by Vasiliy Masnev on 22.02.2023.
//  Copyright 2023 bidapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BIDBannerView, BIDAdFormat, BIDAdInfo;

NS_ASSUME_NONNULL_BEGIN

#pragma mark - BIDBannerViewDelegate

@protocol BIDBannerViewDelegate <NSObject>
@optional
- (void)bannerDidLoad:(BIDBannerView *)banner adInfo:(BIDAdInfo *)adInfo;
- (void)bannerDidDisplay:(BIDBannerView *)banner adInfo:(BIDAdInfo *)adInfo;
- (void)bannerDidFailToDisplay:(BIDBannerView *)banner adInfo:(BIDAdInfo *)adInfo error:(NSError *)error;
- (void)bannerDidClick:(BIDBannerView *)banner adInfo:(BIDAdInfo *)adInfo;
- (void)allNetworksFailedToDisplayAdInBanner:(BIDBannerView *)banner;
@end

#pragma mark - BIDBannerView

@interface BIDBannerView : UIView

@property (nonatomic,weak,nullable) id<BIDBannerViewDelegate> delegate;

// enables or disableas automatic pre-loading of banner ads
@property (nonatomic) BOOL autoload;

// initiate and configure a new instanse of banner view
+ (BIDBannerView *)bannerWithFormat:(BIDAdFormat *)format delegate:(id<BIDBannerViewDelegate>)delegate;

// checks if any ad is displayed on banner
- (BOOL)isAdDisplayed;

// checks if ad is ready to be displayed on banner
- (BOOL)isReadyToRefresh;

// manualy refresh ad of the banner
- (void)refreshAd;

// stops banner autorefresh
- (void)stopAutorefresh;

// starts banner autorefresh. min refresh interval = 20 sec
- (void)startAutorefresh:(NSTimeInterval)refreshInterval;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
