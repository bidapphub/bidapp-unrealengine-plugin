//
//  BIDConfiguration.h
//  bidapp
//
//  Created by Vasiliy Masnev on 22.02.2023.
//  Copyright 2023 bidapp. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BIDConfiguration : NSObject

/**
 Enables test mode in every single ad network in the waterfall.
 */
-(void)enableTestMode;

/**
 Enables console logs in the core bidapp module along with console logs in every single ad network in the waterfall.
 */
-(void)enableLogging;

/**
 Enables interstitial ads. If you want to use interstitials, it is necessary to enable them by calling this method.
 */
-(void)enableInterstitialAds;

/**
 Enables rewarded ads. If you want to use rewarded ads, it is necessary to enable them by calling this method.
 */
-(void)enableRewardedAds;

/**
 Enables banner ads. If you want to use banner ads, it is necessary to enable them by calling this method.
 */
-(void)enableBannerAds;

@end

NS_ASSUME_NONNULL_END
